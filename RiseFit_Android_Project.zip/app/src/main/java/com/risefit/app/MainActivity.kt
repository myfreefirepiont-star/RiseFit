package com.risefit.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar

private val Ink = Color(0xFF080711)
private val Panel = Color(0xFF151126)
private val Purple = Color(0xFFB45CFF)
private val Lilac = Color(0xFFDCC4FF)
private val Muted = Color(0xFFAAA1BD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RiseFitApp(this) }
    }
}

@Composable
fun RiseFitApp(context: Context) {
    var tab by remember { mutableIntStateOf(0) }
    var hour by remember { mutableIntStateOf(6) }
    var minute by remember { mutableIntStateOf(30) }
    var alarmOn by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf(false) }
    var checked by remember { mutableStateOf(setOf<String>()) }
    var goal by remember { mutableStateOf("قوی‌تر شدن و پیشرفت در فوتسال") }
    var goalEdit by remember { mutableStateOf(goal) }

    MaterialTheme(colorScheme = darkColorScheme(background = Ink, surface = Panel, primary = Purple, onPrimary = Color.White)) {
        Scaffold(containerColor = Ink, bottomBar = {
            NavigationBar(containerColor = Panel) {
                val labels = listOf("خانه", "برنامه", "پیشرفت", "تنظیمات")
                val icons = listOf(Icons.Default.Home, Icons.Default.CalendarMonth, Icons.Default.Insights, Icons.Default.Settings)
                labels.forEachIndexed { i, label ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i },
                        icon = { Icon(icons[i], contentDescription = label) }, label = { Text(label, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple, selectedTextColor = Lilac, indicatorColor = Color(0xFF33204A), unselectedIconColor = Muted, unselectedTextColor = Muted))
                }
            }
        }) { pad ->
            when (tab) {
                0 -> Home(pad, hour, minute, alarmOn, { dialog = true }, checked, { k -> checked = if (k in checked) checked - k else checked + k }, { tab = it }, goal)
                1 -> Schedule(pad, checked) { k -> checked = if (k in checked) checked - k else checked + k }
                2 -> Progress(pad, checked.size, goalEdit, { goalEdit = it }, { goal = goalEdit })
                else -> Settings(pad, alarmOn) { dialog = true }
            }
        }
        if (dialog) AlertDialog(
            onDismissRequest = { dialog = false }, containerColor = Panel,
            title = { Text("تنظیم آلارم صبحگاهی", color = Lilac) },
            text = { Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("ساعت دلخواه را وارد کن.", color = Muted)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(hour.toString(), { hour = (it.toIntOrNull() ?: 6).coerceIn(0,23) }, modifier = Modifier.width(90.dp), label = { Text("ساعت") }, singleLine = true)
                    Text(" : ", color = Purple, fontSize = 24.sp)
                    OutlinedTextField(minute.toString(), { minute = (it.toIntOrNull() ?: 30).coerceIn(0,59) }, modifier = Modifier.width(90.dp), label = { Text("دقیقه") }, singleLine = true)
                }
            } },
            confirmButton = { TextButton(onClick = { setAlarm(context, hour, minute); alarmOn = true; dialog = false }) { Text("فعال کردن", color = Purple) } },
            dismissButton = { TextButton(onClick = { alarmOn = false; dialog = false }) { Text("بستن", color = Muted) } }
        )
    }
}

@Composable fun Home(pad: PaddingValues, hour: Int, minute: Int, alarmOn: Boolean, onAlarm: () -> Unit, done: Set<String>, toggle: (String) -> Unit, nav: (Int) -> Unit, goal: String) {
    LazyColumn(Modifier.padding(pad).fillMaxSize().padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(13.dp), contentPadding = PaddingValues(top = 20.dp, bottom = 20.dp)) {
        item { Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("RiseFit", color = Purple, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold); Text("بهترین نسخه خودت در راهه", color = Muted) }; Icon(Icons.Default.Bolt, null, tint = Purple, modifier = Modifier.size(38.dp)) } }
        item { Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(22.dp)).padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("قهرمان شدن از همین لحظه شروع می‌شه", color = Lilac, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(7.dp)); Text("امروز فقط یک قدم به هدفت نزدیک‌تر شو؛ استراحت هم بخشی از پیشرفته.", color = Muted, textAlign = TextAlign.Center, fontSize = 13.sp)
            Spacer(Modifier.height(14.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Alarm, null, tint = Purple); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text("آلارم صبحگاهی", color = Color.White, fontWeight = FontWeight.Bold); Text(if (alarmOn) "فعال: ${hour.toString().padStart(2,'0')}:${minute.toString().padStart(2,'0')}" else "هنوز تنظیم نشده", color = Muted, fontSize = 12.sp) }; Button(onClick = onAlarm, colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("تنظیم") } }
        } }
        item { Text("هدف من", color = Lilac, fontSize = 18.sp, fontWeight = FontWeight.Bold); CardBlock("🎯", goal, "برای ویرایش، وارد بخش پیشرفت شو") { nav(2) } }
        item { Text("برنامه امروز", color = Lilac, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        item { Task("صبح", "بیدار شدن و تحرک سبک", "07:00", "morning", done, toggle) }
        item { Task("بعد از مدرسه", "باشگاه در روزهای برنامه", "15:00", "gym", done, toggle) }
        item { Task("عصر", "فوتسال یا ریکاوری طبق برنامه", "18:00", "futsal", done, toggle) }
        item { Task("شب", "تمرین شکم فقط در روز برنامه‌ریزی‌شده", "19:00", "abs", done, toggle) }
        item { Task("پایان روز", "آرام‌سازی و خواب کافی", "22:00", "sleep", done, toggle) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Action("برنامه هفتگی", Icons.Default.CalendarMonth, Modifier.weight(1f)) { nav(1) }; Action("پیشرفت من", Icons.Default.Insights, Modifier.weight(1f)) { nav(2) } } }
    }
}
@Composable fun CardBlock(emoji: String, title: String, sub: String, click: () -> Unit) { Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).clickable { click() }.padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Text(emoji, fontSize = 24.sp); Spacer(Modifier.width(12.dp)); Column { Text(title, color = Color.White, fontWeight = FontWeight.SemiBold); Text(sub, color = Muted, fontSize = 12.sp) } } }
@Composable fun Task(title: String, detail: String, time: String, key: String, done: Set<String>, toggle: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(15.dp)).clickable { toggle(key) }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
        Checkbox(key in done, { toggle(key) }, colors = CheckboxDefaults.colors(checkedColor = Purple, uncheckedColor = Muted))
        Column(Modifier.weight(1f)) { Text(title, color = Lilac, fontWeight = FontWeight.Bold); Text(detail, color = Muted, fontSize = 12.sp) }
        Text(time, color = Purple, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}
@Composable fun Action(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, click: () -> Unit) { Column(modifier.background(Panel, RoundedCornerShape(16.dp)).clickable { click() }.padding(15.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(icon, null, tint = Purple); Spacer(Modifier.height(7.dp)); Text(label, color = Lilac, fontSize = 13.sp) } }
@Composable fun Schedule(pad: PaddingValues, done: Set<String>, toggle: (String) -> Unit) {
    LazyColumn(Modifier.padding(pad).fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("برنامه هفتگی", color = Purple, fontSize = 27.sp, fontWeight = FontWeight.Bold); Text("روزهای تمرین را با مدرسه و استراحت هماهنگ کن.", color = Muted) }
        item { Task("صبح", "بیدار شدن و تحرک سبک", "صبح", "morning", done, toggle) }
        item { Task("باشگاه", "تمرین قدرتی طبق برنامه مربی", "بعد مدرسه", "gym", done, toggle) }
        item { Task("فوتسال", "تمرین تیمی یا مهارتی", "عصر", "futsal", done, toggle) }
        item { Task("شکم", "فقط اگر امروز روز تمرین است", "شب", "abs", done, toggle) }
        item { Task("ریکاوری", "استراحت بخشی از پیشرفت است", "شب", "sleep", done, toggle) }
        item { Text("این چک‌لیست پایه است؛ زمان‌ها را با برنامه واقعی خودت هماهنگ کن.", color = Muted, fontSize = 12.sp) }
    }
}
@Composable fun Progress(pad: PaddingValues, count: Int, goal: String, edit: (String) -> Unit, save: () -> Unit) {
    LazyColumn(Modifier.padding(pad).fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("پیشرفت من", color = Purple, fontSize = 27.sp, fontWeight = FontWeight.Bold) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Column(Modifier.weight(1f).background(Panel, RoundedCornerShape(16.dp)).padding(15.dp)) { Text("کارهای تیک‌خورده", color = Muted, fontSize = 12.sp); Text("$count", color = Purple, fontSize = 25.sp, fontWeight = FontWeight.Bold) }; Column(Modifier.weight(1f).background(Panel, RoundedCornerShape(16.dp)).padding(15.dp)) { Text("مرحله بعدی", color = Muted, fontSize = 12.sp); Text("روز ۳۰", color = Purple, fontSize = 25.sp, fontWeight = FontWeight.Bold) } } }
        item { Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp)) { Text("هدف من", color = Lilac, fontSize = 18.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)); OutlinedTextField(goal, edit, modifier = Modifier.fillMaxWidth(), label = { Text("هدف شخصی") }, minLines = 2); Spacer(Modifier.height(8.dp)); Button(onClick = save, colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("ذخیره هدف") } } }
        item { Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp)) { Text("مسیر روزهای ۳۰، ۶۰ و ۱۰۰", color = Lilac, fontSize = 18.sp, fontWeight = FontWeight.Bold); listOf("روز ۳۰" to "ساخت عادت‌های پایدار", "روز ۶۰" to "مرور استمرار و تنظیم برنامه", "روز ۱۰۰" to "بررسی پیشرفت واقعی").forEach { (a,b) -> Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Flag, null, tint = Purple); Spacer(Modifier.width(10.dp)); Column { Text(a, color = Lilac, fontWeight = FontWeight.Bold); Text(b, color = Muted, fontSize = 12.sp) } } }; Text("عکس‌های این مراحل باید با انتخاب خودت ثبت شوند. تغییرات بدن برای هر فرد متفاوت است و تضمین نمی‌شود.", color = Muted, fontSize = 12.sp) } }
    }
}
@Composable fun Settings(pad: PaddingValues, enabled: Boolean, alarm: () -> Unit) {
    Column(Modifier.padding(pad).fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("تنظیمات", color = Purple, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        CardBlock("⏰", "آلارم صبحگاهی", if (enabled) "آلارم فعال شده" else "برای تنظیم لمس کن", alarm)
        CardBlock("🎨", "ظاهر برنامه", "تم مشکی و بنفش نئونی") {}
        CardBlock("🔒", "حریم خصوصی", "نسخه اولیه؛ اطلاعات هنوز ذخیره دائمی نمی‌شوند") {}
        Text("RiseFit • نسخه ۱.۰", color = Muted, fontSize = 12.sp)
    }
}
private fun setAlarm(context: Context, hour: Int, minute: Int) {
    val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val intent = Intent(context, AlarmReceiver::class.java)
    val pending = PendingIntent.getBroadcast(context, 2401, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1) }
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !manager.canScheduleExactAlarms()) manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
    else manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
}
